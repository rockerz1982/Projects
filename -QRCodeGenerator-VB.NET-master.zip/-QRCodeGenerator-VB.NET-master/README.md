# -QRCodeGenerator-VB.NET
 QR Code Generator using VB.NET Desktop Application
