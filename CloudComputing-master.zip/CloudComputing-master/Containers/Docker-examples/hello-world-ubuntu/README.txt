docker build -t hello-world-ubuntu .

docker run --publish-all=true -d hello-world-ubuntu

docker ps

curl <app url>
