Greetings
----------

This example shows deployment of a web application that uses MySQL backend.

Check GCP/steps.txt for how to deploy this application on Google Kubernetes Engine.
